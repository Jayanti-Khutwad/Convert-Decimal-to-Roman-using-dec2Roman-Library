import { Component } from '@angular/core';
import {dec2Roman} from 'dec2roman';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  romanEquivalent;
  title = 'Decimal to Roman Conversion';
  pop(x)
  {
   if(x.target.value=='')
   this.romanEquivalent='';
   else
   this.romanEquivalent=dec2Roman(x.target.value);

  }
}
